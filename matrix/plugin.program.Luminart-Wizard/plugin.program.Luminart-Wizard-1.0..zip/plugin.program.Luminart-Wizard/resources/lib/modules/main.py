# -*- coding: utf-8 -*-

from xbmcgui import dialog
from .tools import save_check, save_move1

def main(NAME, NAME2, VERSION, URL, ICON, FANART, DESCRIPTION):
	
	yesInstall = dialog.yesno(NAME, 'O Wizard está pronto para instalar seu build.', nolabel='Cancel', yeslabel='Continue')
	if yesInstall:
	    save_check()
	    save_move1()
	    yesFresh = dialog.yesno('Resetar', 'Deseja limpar todos os dados antes de instalar?', nolabel='Não', yeslabel='Resetar')
	    if yesFresh:
	    	from .freshstart import freshStart
	    	freshStart()
	    from .buildinstall import buildInstall
	    buildInstall(NAME, NAME2, VERSION, URL)
	else:
		return