# -*- coding: utf-8 -*-

import os
import addonvar
import xbmcgui
from .downloader import Downloader
from zipfile import ZipFile
from .save_data import save_check, save_backup,save_restore
from .maintenance import fresh_start

dp = addonvar.dp
dialog = addonvar.dialog
zippath = addonvar.zippath
addon_name = addonvar.addon_name
home = addonvar.home
setting_set = addonvar.setting_set
sleep = addonvar.sleep
headers = addonvar.headers

def main(NAME, NAME2, VERSION, URL, ICON, FANART, DESCRIPTION):
	
	yesInstall = dialog.yesno(NAME, 'O Wizard está pronto para instalar sua build.', nolabel='Cancel', yeslabel='Continue')
	if yesInstall:
	    save_check()
	    save_backup()
	    yesFresh = dialog.yesno('Resetar', 'Deseja limpar todos os dados antes de instalar?', nolabel='Não', yeslabel='Resetar')
	    if yesFresh:
	    	fresh_start()
	    	
	    build_install(NAME, NAME2, VERSION, URL)
	else:
		return

def build_install(name, name2, version, url):
	if os.path.exists(zippath):
		os.unlink(zippath)
	d = Downloader(url)
	if 'dropbox' in url:
		import xbmc
		if not xbmc.getCondVisibility('System.HasAddon(script.module.requests)'):
			xbmc.executebuiltin('InstallAddon(script.module.requests)')
			dialog.ok(name, 'As solicitações estão sendo instaladas.\n Tente novamente quando o Requests terminar de instalar.')
			return
		d.download_build(name,zippath,meth='requests')
	else:
		d.download_build(name, zippath, meth='urllib')
	if os.path.exists(zippath):
		dp.create(addon_name, 'Extraindo arquivos...')
		dp.update(66, 'Extraindo arquivos...')
		zf = ZipFile(zippath)
		zf.extractall(path = home)
		dp.update(100, 'Extracting files...Done!')
		zf.close()
		os.unlink(zippath)
		save_restore()
		setting_set('buildname', name2)
		setting_set('buildversion', version)
		setting_set('firstrun', 'true')
		dialog.ok(addon_name, 'Instalação concluída. Clique em OK para forçar o fechamento do Kodi.')
		os._exit(1)
	else:
		return